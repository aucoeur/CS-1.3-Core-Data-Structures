'''
Write a function called compute_sum() that takes in a single integer argument n and returns the sum of the positive integers from 1 to n. For example compute_sum(4) would return 10, or 1+2+3+4. You need to use a loop to complete this function. Upload your .py file when you are done.
'''

def compute_sum(n):
    # returns sum of positive int from 1 to n
    total = 0
    while n > 0:
        total += n
        n -= 1
    return total

'''
How would you rewrite compute_sum() to be a recursive function? What would the base case be? How would you handle the recursive case? Describe your approach at a high level or using pseudocode. 
'''

def compute_sum_recursive(n):
    total = n
    if n == 0:
        return total
    return total + compute_sum_recursive(n-1)

if __name__ == "__main__":
    # print(compute_sum(4))
    print(compute_sum_recursive(4))
