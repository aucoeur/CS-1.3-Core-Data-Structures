# Quiz 1
### Question 1 - 1 Point
> Decode the 8 bit binary (base 2) number 1110 1100 into its equivalent decimal (base 10) value. Upload a picture or text file showing your work.

#### Answer: `236`

![](q1.jpeg)

### Question 2 - 1 Point
> Encode the decimal (base 10) value 34 into its equivalent binary digits (base 2). Upload a picture or text file showing your work.

#### Answer: `0010 0010`

![](q2.jpg)

### Question 3 - 1 Point
> Decode the hexadecimal (base 16) value 0xC4A into its equivalent decimal (base 10) value. Upload a picture or text file showing your work.

#### Answer: `3146`

![](q3.jpg)

### Question 4 - 1 Point
Encode the decimal (base 10) value 79 into its equivalent hexadecimal (base 16) digits. Upload a picture or text file showing your work.

#### Answer: `0x4F`

![](q4.jpg)

### Question 5
> Write a function called compute_sum() that takes in a single integer argument n and returns the sum of the positive integers from 1 to n. For example compute_sum(4) would return 10, or 1+2+3+4. You need to use a loop to complete this function. Upload your .py file when you are done.

```python
def compute_sum(n):
    total = 0
    while n > 0:
        total += n
        n -= 1
    return total
```

### Question 5.1
> How would you rewrite compute_sum() to be a recursive function? What would the base case be? How would you handle the recursive case? Describe your approach at a high level or using pseudocode. (Hint: this problem is similar to factorial)
```python
def compute_sum_recursive(n):
    total = n
    if n == 0:
        return total
    return total + compute_sum_recursive(n-1)
```

### Question 6
> Describe how binary search works using pseudocode.
```python
# sort array
# set front & end pointers
# find midpoint between front and end pointers
# if item == midpoint, return item
# if item is before midpoint, set end pointer to one before midpoint
# if item is after midpoint, set front pointer to one after midpoint
```

### Question 6.1
> Why is binary search so much more efficient than linear or sequential search?

```text
It is more efficient than linear or sequential search because instead of needing to potentially going through each item in the array, it's going in O(log n ) time, since it recursively rules out half of the array each time it searches.
```